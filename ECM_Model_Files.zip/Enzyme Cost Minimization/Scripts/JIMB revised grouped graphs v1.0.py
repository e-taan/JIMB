#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 12:06:43 2024

@author: connor

Enzyme Cost Minimization of lactate to carboxylates (C4 to C12) via reverse 
beta-oxidation and hexanol, 1,6-hexanediol and adipic acid via reverse beta-
oxidation and hypothetical termination modes.

Explicit specification of redox potentials for NADH, NADHPH, ferredoxin,
rubredoxin and cytochrome C achieved by removing redox equivalents from reactions
and adding free energy changes of redox half reactions to the overall standard 
free energy changes predicted by component contribution prior to enzyme cost 
optimization. See init_thermo_model in JIMB_eQuilibrator_Functions.py. The same
is done for proton translocation.

Method description:
    
    - ATP yield from pFBA results is specified
    - Reaction objects (see equilibrator_api)  are initialized, omitting redox equivalents
    - A list of reaction objects and reaction names are combined into a reaction
    dictionary
    - A flux list, list of redox half reactions to add to pathway reactions, and 
    a list of proton translocation events to add to reactions is declared
    - init_thermo_model creates a ThermodynamicModel object (see equilibrator_pathway)
    from the reaction list
    - Redox half reaction free energy changes and proton translocation free energy
    changes are added to the predicted reaction free energy changes
    - Custom metabolite concentration bounds are set
    - MDF analysis is conducted
        - MDF analysis allows standard ∆Gs to stray from their predictions up to
        a quartile of their chi squared distribution, given their covariance matrix
        returned by the component contribution method. Here, ∆G predictions are not 
        allowed to stray from their means
    - An EnzymeCostModel (equilibrator_pathway) is intialized from the Thermodynamic
    model with the standard free energies predicted by MDF, and enzyme cost 
    minimization is performed
    
Enzyme cost plots are grouped and share a common y axis

"""
#%%

from equilibrator_api import ComponentContribution, Q_
cc = ComponentContribution()
#%% Initiate

import os
os.chdir(os.path.dirname(__file__))
from JIMB_eQuilibrator_functions_revised import init_thermo_model
from JIMB_eQuilibrator_functions_revised import MDF_lite_v2
from JIMB_eQuilibrator_functions_revised import reactions_from_excel 
from JIMB_eQuilibrator_functions_revised import JIMB_RBO_ECM_grouped
import matplotlib.pyplot as plt
from adjustText import adjust_text
from matplotlib import gridspec
plt.rcdefaults()
import pandas as pd

# Directory for saving images and model files

MDF_path_save = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Simulation results/MDF results review/'

MDF_conc_path_save = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Simulation results/MDF concentrations review/'

ECM_path_save = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Simulation results/ECM results review/'

ECM_energies_path_save = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Simulation results/ECM free energies review/'

ECM_models_path_save = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Simulation results/ECM model files review/'

plot_path_save = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Simulation results/Final plots review/'

colors = ["xkcd:grey", "xkcd:red", "xkcd:blue"]

# Simulation Configuration

config_dict = {'flux_unit': 'Unitless',
               'version': '3',
               'kcat_source': 'fwd',
               'denominator': 'CM',
               'regularization': 'volume', 
               'objective': 'enzyme',
               'standard_concentration': '1 M', 
               'solver': 'CLARABEL', 
               'algorithm': 'ECM', 
               'p_h': '6',
               'ionic_strength': '250 mM',
               'p_mg': '3',
               'dg_confidence' : '0'}

# Standard Concentration Bounds

standard_lb = 0.001
standard_ub = 10

# Specify reduction potentials (V)

E_fe = -0.400 # Ferredoxin
E_rub = -0.075 # Rubredoxin
E_cyt = 0.254 # Cytochrome C
E_nadh = -0.280 # NADH
E_nadph = -0.370 # NADPH

lam_atp_dict = {} # Container for enzyme costs per ATP flux 
atp_dict = {} # Container for ATP yields on lactate

def wrap(title, model_file, pmf, ATP, standard, ax, base, ymax):
    
    """ Wraps model construction from excel file, thermodynamic model initialization,
    MDF and ECM. Creates MDF graphs, plots free energies of enzyme cost minimum,
    plots enzyme costs, saves thermodynamic model and ECM solution as tsv,
    return enzyme cost per unit ATP flux (g/mmol ATP/hr) and enzyme cost relative
    to a standard """
    
    compounds = pd.read_excel(model_file, sheet_name = 'Compounds', index_col = 0)
    reactions = pd.read_excel(model_file, sheet_name = 'Reactions')
        
    reaction_dict, redox_list, proton_list = reactions_from_excel(reactions, compounds, cc)
    compound_dict = {name : cc.get_compound(compounds['ID'].loc[name]) for name in compounds.index}
    lower_bounds = compounds['Lower Bound'].fillna(standard_lb).apply(lambda x: Q_(x, 'mM'))
    upper_bounds = compounds['Upper Bound'].fillna(standard_ub).apply(lambda x: Q_(x, 'mM'))
    fluxes = reactions['Flux'].to_list()

    thermo_model = init_thermo_model( reaction_dict, # Dict{Reaction Name : Reaction Object}
                                      compound_dict, # Dict{Compound Name : Compound Object}
                                      redox_list,
                                      proton_list,
                                      fluxes,
                                      lower_bounds,
                                      upper_bounds,
                                      E_fe,
                                      E_rub,
                                      E_cyt,
                                      E_nadh,
                                      E_nadph,
                                      pmf,
                                      config_dict,
                                      cc
                                      )

    mdf_sol = MDF_lite_v2(thermo_model)

    Km_units = 'mM'
    crc_units = '1/s'
    protein_mass_units = 'kDa'
    compound_mass_units = 'Da'
    crc_array = reactions['Forward Catalytic Constant'].to_list()
    protein_mass_array = reactions['Protein Mass'].to_list()
    compound_mass_array = compounds['Compound Mass'].to_list()
    Km_df = pd.read_excel(model_file, sheet_name = 'Michaelis Constants')
    new_dgs = mdf_sol.standard_dg_prime

    protein_cost, protein_cost_per_ATP, ecm_sol = JIMB_RBO_ECM_grouped(thermo_model,
                                            new_dgs,
                                            Km_df,
                                            Km_units,
                                            crc_array,
                                            crc_units,
                                            protein_mass_array,
                                            protein_mass_units,
                                            compound_mass_array,
                                            compound_mass_units,
                                            ATP,
                                            standard,
                                            title, 
                                            ECM_path_save, 
                                            colors,
                                            ax,
                                            base,
                                            ymax
                                            )
    
    return protein_cost, protein_cost_per_ATP

base = 0.0004175
ymax = 2.5

#%% MCFAs

fig1, axes = plt.subplots(3, 2, tight_layout = True, dpi = 300, figsize = (20, 25),
                          sharey = True)
plt.rcParams.update({'font.size': 20})
### Lactate to Butyrate ###

title = 'Lactate to Butyrate'
model_file = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Model files/Lactate to Butyrate.xlsx'

pmf = 0.200 # Chemical potential of proton crossing membrane (in to out) in Volts
ATP = 0.25 # ATP yield per lactate
standard = 1 # Placeholder for butyrate enzyme cost per unit ATP flux
ax = axes[0, 0]

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

standard = protein_cost_per_ATP

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

atp_dict['Butyrate'] = ATP
lam_atp_dict['Butyrate'] = protein_cost_per_ATP

### Lactate to Caproate ###

title = 'Lactate to Hexanoate'
model_file = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Model files/Lactate to Caproate.xlsx'

pmf = 0.200 # Chemical potential of proton crossing membrane (in to out) in Volts
ATP = 0.33 # ATP yield per lactate
ax = axes[0, 1]

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

atp_dict['Hexanoate'] = ATP
lam_atp_dict['Hexanoate'] = protein_cost_per_ATP

### Lactate to Octanoate ###

title = 'Lactate to Octanoate'
model_file = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Model files/Lactate to Octanoate.xlsx'

# Specify chemical potential of proton crossing membrane (in to out)

pmf = 0.100 # Chemical potential of proton crossing membrane (in to out) in Volts
ATP = 0.375 # ATP yield per lactate
ax = axes[1, 0]

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

atp_dict['Octanoate'] = ATP
lam_atp_dict['Octanoate'] = protein_cost_per_ATP

### Lactate to Decanoate ###

title = 'Lactate to Decanoate'
model_file = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Model files/Lactate to Decanoate.xlsx'

# Specify chemical potential of proton crossing membrane (in to out)

pmf = 0.100 # Chemical potential of proton crossing membrane (in to out) in Volts
ATP = 0.4 # ATP yield per lactate
ax = axes[1, 1]

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

atp_dict['Decanoate'] = ATP
lam_atp_dict['Decanoate'] = protein_cost_per_ATP

### Lactate to Dodecanoate ###

title = 'Lactate to Dodecanoate'
model_file = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Model files/Lactate to Dodecanoate.xlsx'

# Specify chemical potential of proton crossing membrane (in to out)

pmf = 0.100 # Chemical potential of proton crossing membrane (in to out) in Volts
ATP = 0.416666667 # ATP yield per lactate
ax = axes[2, 0]

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

atp_dict['Dodecanoate'] = ATP
lam_atp_dict['Dodecanoate'] = protein_cost_per_ATP

fig1.delaxes(axes[2, 1])

handles, labels = axes[1, 0].get_legend_handles_labels()
plt.figlegend(handles, labels , bbox_to_anchor=[0.75, 0.2], 
           loc='center')
axes[0, 1].set_ylabel('')
axes[1, 1].set_ylabel('')
axes[0, 1].yaxis.set_ticks_position('none') 
axes[1, 1].yaxis.set_ticks_position('none') 

fig1.savefig(plot_path_save+'MCFA ECM.png', dpi = 300, bbox_inches = 'tight')

#%% Novel Products

fig2, axes = plt.subplots(2, 2, tight_layout = True, dpi = 300, figsize = (20, (2/3)*25),
                          sharey = True)
plt.rcParams.update({'font.size': 20})

### Lactate to Hexanol (AdhE) ###

title = 'Lactate to Hexanol (AdhE)'
model_file = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Model files/Lactate to Hexanol (AdhE).xlsx'

# Specify chemical potential of proton crossing membrane (in to out)

pmf = 0.100 # Chemical potential of proton crossing membrane (in to out) in Volts
ATP = 0.333 # ATP yield per lactate
ax = axes[0, 0]

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

atp_dict['Hexanol (AdhE)'] = ATP
lam_atp_dict['Hexanol (AdhE)'] = protein_cost_per_ATP

### Lactate to Hexanol (AOR) ###

title = 'Lactate to Hexanol (AOR)'
model_file = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Model files/Lactate to Hexanol (AOR).xlsx'

# Specify chemical potential of proton crossing membrane (in to out)

pmf = 0.100 # Chemical potential of proton crossing membrane (in to out) in Volts
ATP = 0.5 # ATP yield per lactate
ax = axes[0, 1]

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

atp_dict['Hexanol (AOR)'] = ATP
lam_atp_dict['Hexanol (AOR)'] = protein_cost_per_ATP

### Lactate to 1,6-hexanediol ###

title = 'Lactate to 1,6-hexanediol'
model_file = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Model files/Lactate to 1,6-hexanediol.xlsx'

# Specify chemical potential of proton crossing membrane (in to out)

pmf = 0.100 # Chemical potential of proton crossing membrane (in to out) in Volts
ATP = 0.5 # ATP yield per lactate
ax = axes[1, 0]

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

atp_dict['1,6-hexanediol'] = ATP
lam_atp_dict['1,6-hexanediol'] = protein_cost_per_ATP

### Lactate to Adipic Acid ###

title = 'Lactate to Adipic Acid'
model_file = '/Users/connor/Documents/Projects/Fermentation thermo and kinetics/\
JIMB article review/Model files/Lactate to Adipic Acid.xlsx'

# Specify chemical potential of proton crossing membrane (in to out)

pmf = 0.100 # Chemical potential of proton crossing membrane (in to out) in Volts
ATP = 0.333 # ATP yield per lactate
ax = axes[1, 1]

protein_cost, protein_cost_per_ATP = wrap(title, model_file, pmf, ATP, standard, 
                                          ax, base, ymax)

atp_dict['Adipic Acid'] = ATP
lam_atp_dict['Adipic Acid'] = protein_cost_per_ATP

handles, labels = axes[1, 0].get_legend_handles_labels()
plt.figlegend(handles, labels , bbox_to_anchor=[0.5, -0.05], 
           loc='center')

axes[0, 1].set_ylabel('')
axes[1, 1].set_ylabel('')
axes[0, 1].yaxis.set_ticks_position('none') 
axes[1, 1].yaxis.set_ticks_position('none') 

fig2.savefig(plot_path_save+'Novel Products ECM.png', dpi = 300, bbox_inches = 'tight')

#%% Plotting enzyme cost and proteome partitioning as a function of growth rate
### Fitted by requiring that butyrate producers grow at 1 with an EC of 1 and 
### proteome fraciton of 0.1.

plt.rcdefaults()

gamma = -1/7 # ATP consumed per anabolic biomass per hour (smaller than 0!)
Y = 10 # biomass produced per ATP consumed
ATP = 0 # ATP pool
W0 = 0.2 # non-catalytic biomass fraction
b = 0 # Maintenance ATP flux 
max_relative_EC = 6

def lam_func(EC):
    growth = -((1 - W0)/EC - b)/ (1/(gamma*Y*EC) - 1/Y - ATP)
    return growth

lam_points_dict = {list(lam_atp_dict.keys())[i] : (list(lam_atp_dict.values())[i]/lam_atp_dict['Butyrate'], 
                                             lam_func(list(lam_atp_dict.values())[i]/lam_atp_dict['Butyrate'])) 
                                             for i in range(len(list(lam_atp_dict.values())))}

# lam_min = lam_func(max_relative_EC)
lam_min = 0.6
lam_step = 0.001
stop = 0.1


def EC_func(lam, W0):
    # Enzyme cost per unit ATP flux
    return ((1 - W0)/lam + 1/(gamma*Y)) / (ATP + 1/Y + b/lam)

def WE_func(lam, W0):
    # catabolic fraction
    Cost = EC_func(lam, W0)
    return Cost*(lam*(ATP + 1/Y) + b)

def WR_func(WE, W0):
    return 1 - WE - W0

lam = lam_min
EC = EC_func(lam, W0) 
WE = WE_func(lam, W0)
WR = WR_func(WE, W0)

lam_array = [lam]
EC_array = [EC]
WE_array = [WE]
WR_array = [WR]

while WE > stop:
    lam += lam_step
    EC = EC_func(lam, W0) 
    WE = WE_func(lam, W0)
    WR = WR_func(WE, W0)

    if WE > stop:
        lam_array += [lam]
        EC_array += [EC]
        WE_array += [WE]
        WR_array += [WR]

colors = ["xkcd:grey", "xkcd:red", "xkcd:blue"]

fig = plt.figure()

fig.set_figheight(8)
fig.set_figwidth(8)

spec = gridspec.GridSpec(ncols=1, nrows=3,
                         hspace=0.5, 
                         height_ratios=[3, 1, 1])

# Plot relative enzyme investment per unit ATP flux vs. relative growth rate
ax0 = fig.add_subplot(spec[0])
ax0.plot(lam_array, EC_array, label = 'Enzyme Investment', color = 'black')

# Plot catalytic biomass fractions as a function of relative growth rate
ax1 = fig.add_subplot(spec[1])
ax1.set_ylim([0, 1])
ax1.fill_between(lam_array, WE_array, color = colors[0], alpha = 0.7, 
                    label = 'Catabolic Fraction')
ax1.fill_between(lam_array, [WR_array[i] + WE_array[i] for i in range(len(WE_array))],
                    [WE_array[i] + 0.05 for i in range(len(WE_array))], color = colors[2],
                    alpha = 0.8, label = 'Anabolic Fraction')

ax1.text(0.88, 0.5, 'Anabolic Biomass', color = 'white')

ax1.text(0.63, 0.1, 'Catabolic Biomass', color = 'white')

# Plot ATP yields
ax2 = fig.add_subplot(spec[2])
sorted_lam_points_dict = {k: v for k, v in reversed(sorted(lam_points_dict.items(), key=lambda item: item[1]))}
new_atp_dict = {product : atp_dict[product] for product in sorted_lam_points_dict.keys()}
ax2.bar(new_atp_dict.keys(), new_atp_dict.values(), color = colors[1])
ax2.set_ylim(top = 0.6)
plt.setp( ax2.xaxis.get_majorticklabels(), rotation=45, ha="right", rotation_mode="anchor")

ax1.set_xlabel('Specific Growth Rate\nRelative to Butyrate')
ax0.set_ylabel('Enzyme Investment\nper ATP Flux\nRelative to Butyrate')
ax1.set_ylabel('Biomass\nFraction')
ax0.xaxis.set_visible(False)

ax2.set_ylabel('ATP Yield\non Lactate')

box = ax0.get_position()
box.y0 = box.y0 - 0.08
box.y1 = box.y1 
ax0.set_position(box)


# Plot product points
for name in lam_points_dict.keys():
    ax0.scatter(lam_points_dict[name][1], lam_points_dict[name][0], color = 'black')

texts = [ax0.annotate(name, (lam_points_dict[name][1], lam_points_dict[name][0]),
                            # xytext = (lam_points_dict[name][1]-0.07, lam_points_dict[name][0]+1.8),
                            xytext = (lam_points_dict[name][1], lam_points_dict[name][0]),
                            # textcoords='offset points',
                            arrowprops = dict(arrowstyle='->', relpos = (0.5, 1.), shrinkB = 0.5),
                            fontsize = 8,
                            ) 
                            for name in lam_points_dict.keys()] 

adjust_text(texts, 
            ax = ax0,
            x = lam_array,
            y = EC_array
            )

texts[0].set_position((0.99, 1.5))
texts[4].set_position((0.76, 5.5))
texts[8].set_position((0.68, 6))
    
plt.savefig(plot_path_save+'Resource Allocation model qualitative everything.png', 
            dpi = 300, bbox_inches = 'tight')

